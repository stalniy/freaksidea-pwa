<?php
class Freaks_Banners_Model_Observer
{
    /**
     * Add a customer order comment when the order is placed.
     * Listen "adminhtml_block_html_before" event
     *
     * @param Varien_Event_Observer $observer
     * @return Freaks_Banners_Model_Observer
     */
    public function addGroupField(Varien_Event_Observer $observer)
    {
        $block  = $observer->getEvent()->getBlock();
        $parent = $block->getParentBlock();

        if (!$parent || 'cms_block_edit' != $parent->getNameInLayout()) {
            return $this;
        }

        $model = Mage::registry('cms_block');
        $form  = $block->getForm();
        $form->getElement('base_fieldset')->addField('frk_group_id', 'select', array(
            'label'     => Mage::helper('freaks_banners')->__('Group'),
            'title'     => Mage::helper('freaks_banners')->__('Group'),
            'name'      => 'frk_group_id',
            'required'  => false,
            'options'   => Mage::helper('freaks_banners')->getBannerGroups(),
        ), 'identifier');
        $form->setValues($model->getData());

        return $this;
    }
}
