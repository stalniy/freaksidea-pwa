<?php
class Freaks_Banners_Block_Group extends Mage_Core_Block_Template
{
    protected
        $_groupId,
        $_collection;

    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('freaks/banners.phtml');
    }

    public function setGroup($groupId)
    {
        $this->_groupId = $groupId;
        return $this;
    }

    public function getBannersCollection()
    {
        if ($this->_collection) {
            return $this->_collection;
        }
        return $this->_collection = Mage::getResourceModel('cms/block_collection')
            ->addFieldToFilter('frk_group_id', $this->_groupId)
            ->addStoreFilter(Mage::app()->getStore()->getId())
            ->addFieldToFilter('is_active', true);
    }
}
