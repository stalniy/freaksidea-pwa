<?php
class Freaks_Banners_Helper_Data extends Mage_Core_Helper_Abstract
{
    public function getBannerGroups()
    {
        return array(
            ''             => $this->__('Ungrouped'),
            'main.top'     => $this->__('Main Page Top'),
            'category.top' => $this->__('Category Top'),
            'search.top'   => $this->__('Search Top'),
            'cart.top'     => $this->__('Cart Top'),
            'left'         => $this->__('Left Column'),
            'right'        => $this->__('Right Column'),
        );
    }
}
