<?php
/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;

$installer->startSetup();

$installer->run("
ALTER TABLE {$this->getTable('cms/block')}
    ADD COLUMN frk_group_id VARCHAR(255),
    ADD INDEX frk_group_idx(frk_group_id);
");

$installer->endSetup();
