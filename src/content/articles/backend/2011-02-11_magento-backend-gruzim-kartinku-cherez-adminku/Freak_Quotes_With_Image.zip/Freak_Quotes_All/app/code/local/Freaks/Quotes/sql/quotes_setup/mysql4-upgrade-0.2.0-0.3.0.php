<?php
$installer = $this;
$installer->startSetup();

$installer->run("
ALTER TABLE `{$this->getTable('freaks_quotes/quote')}` ADD `image` VARCHAR( 255 ) NOT NULL
");
 
$installer->endSetup();
