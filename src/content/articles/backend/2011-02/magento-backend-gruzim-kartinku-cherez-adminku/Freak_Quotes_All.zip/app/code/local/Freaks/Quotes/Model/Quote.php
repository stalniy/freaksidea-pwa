<?php
class Freaks_Quotes_Model_Quote extends Mage_Core_Model_Abstract
{
 
    protected function _construct()
    {
        $this->_init('freaks_quotes/quote');
    }
}
