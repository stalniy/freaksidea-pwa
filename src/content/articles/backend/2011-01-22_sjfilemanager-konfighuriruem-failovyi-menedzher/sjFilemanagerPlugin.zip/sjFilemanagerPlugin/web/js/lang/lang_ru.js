/*
 * This file is part of the sjFilemanager package.
 * (c) 2010-2011 Stotskiy Sergiy <serjo@freaksidea.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
/**
 * Lang hash
 * 
 * @package    sjFilemanager
 * @author     Stotskiy Sergiy <serjo@freaksidea.com>
 * @version    SVN: $Id$
 */
var $_LANG = {
    PROJECT_TITLE: 'Файловый менеджер',
    VIEW_PROPERTY: 'Просмотр свойств папки',
    CREATE: 'Создание новой папки ',
    DANGER_SYMOBLS: "Имя файла не должно содержать следующие знаки: \ /: *? <> | \" ",
    LOAD: 'Загрузить',
    PERMS: 'Права доступа',
    WANT_REMOVE: 'Вы действительно хотите удалить файл(ы)?',
    TITLE_WARNING: 'Внимание!',
    UPLOAD_BTN_TEXT: 'Файлы...'
};
