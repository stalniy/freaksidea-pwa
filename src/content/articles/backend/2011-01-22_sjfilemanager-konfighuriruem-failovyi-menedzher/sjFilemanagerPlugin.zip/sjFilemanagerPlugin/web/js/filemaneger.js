
/*
 * This file is part of the sjFilemanager package.
 * (c) 2010-2011 Stotskiy Sergiy <serjo@freaksidea.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
/**
 * File manager functionality
 *
 * @package    sjFilemanager
 * @author     Stotskiy Sergiy <serjo@freaksidea.com>
 * @version    SVN: $Id$
 */
sjs.globals.fm={};
var FileManage = new sjs.plugin({
    __construct:function(content, cfg, events){
        this.id         = content[0].sjsEventId;
        this.dirUrl     = cfg.dirUrl;
        this.actionUrl  = cfg.actionUrl;
        this.events     = events || {};
        this.dirStek    = null;
        this.fileStek   = null;
        this.windows    = {};
        this.requestData  = {};
        this.lastClicked  = null;
        this.actionsBlock = sjs(cfg.actionSel);
        this.hasStekChanges = false;

        if (cfg.upload && cfg.upload.object) {
            this.__uploadSuccess = cfg.upload.upload_success_handler;
            cfg.upload.upload_url = this.actionUrl;
            cfg.upload.upload_success_handler = this.uploadSuccess;
            cfg.upload[cfg.upload.onReadyEventName] = this.onUploaderReady;

            this.uploadObject = new cfg.upload.object(cfg.upload);
            this.uploadObject.__file_manager_id = this.id;
        }

        this.actionsBlock[0].__FileManageId__ = this.id;
        this.findLastClicked(content.first()[0]);
        if (sjs.isFn(events.onInit)) {
            events.onReady.call(this, content);
        }
        this.initialize(content);
        sjs.globals.fm[this.id]=this
    },
    __destruct:function(){
        delete sjs.globals.fm[this.id];
        this.clearStek('dir', 'file');
        for (name in this.windows) {
            if (this.windows[name].__destruct) {
                this.windows[name].__destruct();
            }
        }
        this.windows=this.requestData=this.events=this.lastClicked=this.id=null;
    },
    findLastClicked:function(tbl){
        tbl=tbl.tBodies[0];
                if (tbl.rows[0]) {
                    this.lastClicked=(tbl.rows[0].id=='parent-dir'&&tbl.rows[1])||tbl.rows[0];
                }
        return tbl
    },
    select:function(to){
        var body=to.offsetParent.rows, i_from=this.lastClicked.rowIndex, i_to=to.rowIndex,
          i=Math.abs(i_to - i_from) + 1, from = (i_from > i_to) && i_from || i_to;
        while(i--) this.checked(body[from-i], 'selected', 1)
    },
    choose:function(tr){
        if(tr.className){
            this.checked(tr,'',0)
        }else{
            this.lastClicked=tr;
            this.checked(tr,'selected',1)
        }
    },
    checked:function(tr,cls,chk){
        var checkbox = tr.firstChild.firstChild;
        tr.className=cls;
        if (sjs.nodeName(checkbox,'input')) {
            checkbox.checked=chk
        }
    },
    getChecked:function(parent) {
        return sjs('tr.selected', parent || this.lastClicked.parentNode);
    },
    makeStek:function(){
      if (!this.hasStekChanges) return false;

        var files=[], dirs=[];
        this.getChecked().iterate(function(){
            var chk = sjs('input[type="checkbox"]', this.cells[0]);
            if(!chk.length) return true;
            var td=this.cells[1];
            chk = chk[0];

            if (sjs.className.has(td,'dir')) {
                dirs[dirs.length] = chk.value
            } else {
                files[files.length] = chk.value
            }
        });
        this.fileStek=files;
        this.dirStek=dirs;
        this.hasStekChanges = false;
        dirs=files=null
    },
    clearStek: function(){
        var i = arguments.length, stek='';
        this.hasStekChanges = false;
        while (i--) {
            stek = arguments[i] + 'Stek';
            if(this[stek]) {
                this[stek] = null
            }
        }
    },
    emptyStek: function() {
        return !this.dirStek && !this.fileStek
            || !this.dirStek.length && !this.fileStek.length
    },
    getCurrentPath: function(tbl){
        tbl && this.findLastClicked(tbl);
        if (!this.lastClicked) return '/';

        return this.lastClicked.parentNode.className;
    },
    displayFullPath: function(dir){
        this.actionsBlock.find('div:last-child > *:last-child')
            .text(dir);
    },
    open: function(path){
        path = path.trim();
        if (path) {
            this.doAction('opendir', path, this.lastClicked);
        }
    },
    reset: function(){
        var div = this.lastClicked.offsetParent.parentNode;
        this.clearStek('dir', 'file');
        sjs(div).find('input[type="checkbox"]:checked').iterate(function(){
            sjs(this.parentNode.parentNode).removeClass('selected');
            this.checked = false
        });
        this.restoreDefaultActions();
        return this;
    },
    initialize:function(content){
        sjs.event.unselect(content[0]);
        this.reset();
        content.onEvent('mousedown',function(e){
            var $this=sjs.event.caller(e), key=sjs.event.key(e), mn=sjs.globals.fm[this.sjsEventId], tr, actions, selected, dir;
            while ($this && !sjs.nodeName($this,'td')) $this=$this.parentNode;
            if(!sjs.nodeName($this,'td')) return false;

            tr=$this.parentNode;
            selected=mn.getChecked(tr.parentNode);

            if(key.shift){
                selected.iterate(function(){mn.checked(this,'',0)});
                mn.checked(tr,'selected',1);
                mn.select(tr)
            }else if(key.ctrl){
                mn.choose(tr)
            }else{
                mn.lastClicked=tr;
                selected.iterate(function(){mn.checked(this,'',0)});
                mn.checked(tr,'selected',1)
            }

            mn.hasStekChanges = true;
            mn.prepareActions();
        }).onEvent('dblclick',function(e){
            var $this=sjs.event.caller(e), key=sjs.event.key(e), mn=sjs.globals.fm[this.sjsEventId],
            tr, i = 10;
            while($this && !sjs.nodeName($this, 'td') && i--) $this=$this.parentNode;

            if (key.shift || key.ctrl || !sjs.nodeName($this,'td')) {
                return false;
            }
            tr = $this.parentNode;
            if (sjs('.folder', tr).setClass('loading').length) {
                var dir = sjs.getText(tr.cells[1]) || '';
                mn.hasStekChanges = true;
                mn.doAction('opendir', mn.getCurrentPath() + dir.trim(), tr);
            } else if (sjs.isFn(mn.events.onDblClick)) {
                mn.events.onDblClick.call(mn, tr)
            }

            mn=tr=$this=null
        });
        this.actionsBlock.onEvent('click',function(e){
            var $this=sjs.event.caller(e), mn=sjs.globals.fm[this.__FileManageId__];

            if (!sjs.nodeName($this,'a') || !mn.isActionEnabled($this)) return false;

            mn.doAction($this.name, $this);
            return false
        });
    },
    isActionEnabled: function(actionBtn) {
        var a = sjs(actionBtn);

        this.makeStek();
        var has_dirs  = (this.dirStek || []).length,
            has_files = (this.fileStek || []).length;

        return has_dirs  && !has_files && !a.hasClass('onlyFile')
            || has_files && !has_dirs  && !a.hasClass('onlyDir')
            || has_files && has_dirs   && (!a.hasClass('onlyDir') || !hasClass('onlyFile'))
            || !a.hasClass('sjsFMdinamic')
            || has_dirs || has_files
            || this.requestData.files
    },
    hasAction: function(name) {
        return sjs.isFn(this[name + 'Action']);
    },
    doAction: function(name) {
        if (!this.hasAction(name) || name == 'do' || name == 'has' || name == 'set') return false;

        var args = Array.prototype.slice.call(arguments,1);
        this[name + 'Action'].apply(this, args || []);
    },
    setAction: function(name, callback){
        this[name + 'Action'] = callback;
    },
    prepareActions: function(){
        this.makeStek();
        var has_dirs = (this.dirStek || []).length,
            has_files = (this.fileStek || []).length;

        if (has_files && has_dirs) {
            this.actionsBlock.setClass('enabledGeneralActions')
                .removeClass('enabledDirActions')
                .removeClass('enabledFileActions')
        } else if (has_files && !has_dirs) {
            this.actionsBlock.setClass('enabledFileActions')
                .setClass('enabledGeneralActions')
                .removeClass('enabledDirActions')
        } else if (has_dirs && !has_files) {
            this.actionsBlock.setClass('enabledDirActions')
                .setClass('enabledGeneralActions')
                .removeClass('enabledFileActions')
        } else {
            this.restoreDefaultActions()
        }
    },
    restoreDefaultActions: function(){
        this.actionsBlock.removeClass('enabledGeneralActions')
            .removeClass('enabledDirActions')
            .removeClass('enabledFileActions')
    },
    opendirAction:function(dir,content,refresh){
        refresh = !!refresh;
        if (refresh) {
            this.actionsBlock.setClass('dofileaction');
        }

        sjs.query(this.dirUrl, { dirpath: dir }, FileManage.opendirCallback, 1,{
            wrapper: content.offsetParent.parentNode,
            isRefresh: refresh
        });
        this.restoreDefaultActions();
    },
    transformAction:function(btn){
        var $do=sjs(btn.parentNode);

        if($do.hasClass('filemanagerfixed')){
            $do.removeClass('filemanagerfixed');
            sjs.className.set(btn,'active')
        }else{
            $do.setClass('filemanagerfixed');
            sjs.className.remove(btn,'active')
        }
    },
    refreshAction:function(btn){
        var path=this.getCurrentPath();
        this.opendirAction(path.substr(0,path.length-1),this.lastClicked,1);
    },
    cutAction:function(btn, onlyCopy){
        var $this=sjs(btn.parentNode);

        this.makeStek();
        this.requestData.files = [].concat(this.fileStek, this.dirStek);
        this.requestData.baseDir  = this.getCurrentPath();
        this.requestData.onlyCopy = onlyCopy;
        $this.find('a[name="paste"]').removeClass('sjsFMdisabled')
             .setClass('sjsFMenabled');
    },
    copyAction:function(btn){
        this.cutAction(btn, true);
    },
    pasteAction:function(btn){
        if(!this.requestData.files || !this.requestData.files.length) {
            FileManage.pasteCallback.call({
                args: { object_id: this.id }
            });
            return false
        }

        sjs.query(this.actionUrl, sjs.extend({
            action: 'paste',
            path: this.getCurrentPath()
        }, this.requestData),FileManage.pasteCallback,1,{
            object_id: this.id
        });
    },
    removeAction:function(btn){
        this.actionsBlock.find('img').setClass('unvisible');

        FileManage.createWindow({
            id: this.id,
            title: $_LANG.WANT_REMOVE,
            arguments: { action: 'remove' }
        },'confirm');
    },
    renameAction:function(btn){
        this.actionsBlock.find('img').setClass('unvisible');

        this.makeStek();

        if(this.emptyStek()){
            return false;
        }
        var stek = this.dirStek.concat(this.fileStek),
            p = stek[0].lastIndexOf('.'),
            td = this.lastClicked.cells[1];

        sjs(td).next().css('display', 'none');
        td.setAttribute('colSpan','2');

        if(p==-1 || !p) {
            p = stek[0].length;
        }
        sjs.event.select(this.lastClicked.offsetParent.parentNode);
        var inp = sjs('label', td)
            .html('<input type="text" name="sjsFMnewName" value="'+stek[0]+'" />')
            .first();
        sjs.selectText(inp[0], 0, p);
        inp[0].focus();
        inp[0].__file_manage_id = this.id;

        inp.onEvent('keydown',function(e){
            var key=sjs.event.key(e);
            if(key.code==13){
                this.blur();
                return false
            }
        }).onEvent('blur', FileManage.renameCallback);
    },
    downloadAction:function(btn){
        this.actionsBlock.find('img').setClass('unvisible');

        sjs.query(this.actionUrl,{
            action: 'download',
            path: this.getCurrentPath(),
            files: document.sjs_form
        }, FileManage.ajaxCallback, true, {
            object_id: this.id
        }, {
            loader: 'form',
            method: 'POST'
        });
    },
    permsAction:function(btn){
        this.actionsBlock.find('img').setClass('unvisible');
        this.makeStek();
        if(!this.dirStek.length && !this.fileStek.length) return false;

        FileManage.createWindow({
            id: this.id,
            title:$_LANG.PERMS,
            postData:{
                action: 'perms',
                files: this.dirStek.concat(this.fileStek),
                path: this.getCurrentPath()
            },
            arguments: { action: 'perms' }
        },null,this.actionUrl);
    },
    dirInfoAction:function(btn){
        this.actionsBlock.find('img').setClass('unvisible');
        this.makeStek();
        var files = 0;
        if (this.dirStek || this.fileStek) {
            var files = this.dirStek.concat(this.fileStek);
            files.length = 1;
        }

        FileManage.createWindow({
            id: this.id,
            postData: {
                files:  files,
                action: 'dir_info',
                path: this.getCurrentPath()
            }
        },null,this.actionUrl);
    },
    createDirAction:function(btn){
        this.actionsBlock.find('img').setClass('unvisible');

        FileManage.createWindow({
            id: this.id,
            title: $_LANG.CREATE,
            arguments: { action: 'createDir' }
        }, 'create');
    },
    uploadAction:function(btn){
        if (!this.uploadObject) {
            return false;
        }
        this.actionsBlock.find('img').setClass('unvisible');
        this.getWindow('upload', $_LANG.LOAD);
    },
    onUploaderReady: function(){
        var uploadObject = this, mn = sjs.globals.fm[uploadObject.__file_manager_id],
            postParams = {
                action: 'upload',
                print_error: uploadObject.getName() == 'SWFUpload',
                path: mn.getCurrentPath()
            };

        postParams[$_Request.prototype.session_name] = $_Request.prototype.getSession();
        mn.uploadObject.setPostParams(postParams);
    },
    uploadSuccess: function(){
        var uploadObject = this, result = true,
            mn = sjs.globals.fm[uploadObject.__file_manager_id];

        if (sjs.isFn(mn.__uploadSuccess)) {
            result = mn.__uploadSuccess.apply(uploadObject, Array.prototype.slice.call(arguments,0));
        }

        if (result) {
            mn.doAction('refresh');
        }
    },
    getWindow: function(name, title) {
        var w = this.windows[name];
        if (w) {
            w.show();
            return w;
        }

        w = FileManage.createWindow({
            id: this.id,
            title: title,
            content: sjs('#sj' + sjs.capitalize(name) + 'Tmpl').first()[0],
            arguments: { action: name }
        });

        w.find('.sjs_wcontent').setClass('sjs_uploader');
        w.onclose = function(){
            this.hide();
            return false;
        };
        return this.windows[name] = w;
    }
});

FileManage.ajaxCallback = function(js, html){
   var mn=sjs.globals.fm[this.args.object_id];

   if(js && js.response && js.response.status == 'error'){
      if (sjs.isFn(mn.events.onServerError)) {
          mn.events.onServerError.call(mn, js, html);
      }
      mn.actionsBlock.find('img').setClass('unvisible');
   }else{
      mn.doAction('refresh');
      mn.clearStek('file', 'dir');
      mn.requestData = {};
   }

   return mn
};

FileManage.opendirCallback = function(js,txt){
   var mn=sjs.globals.fm[this.args.wrapper.sjsEventId], curDir;

   this.args.wrapper.innerHTML=txt;
   curDir=mn.getCurrentPath(this.args.wrapper.firstChild);
   if (mn.events.opendir) {
      mn.events.opendir.call(mn,this.args.wrapper,curDir);
   }
   if (this.args.isRefresh) {
      mn.actionsBlock.removeClass('dofileaction');
   } else {
      mn.displayFullPath(curDir);
   }
};

FileManage.pasteCallback = function(js,txt){
    var mn = FileManage.ajaxCallback.call(this, js, txt);
    if (js.response.status != 'error') {
       mn.actionsBlock.find('a[name="paste"]')
        .setClass('sjsFMdisabled')
        .removeClass('sjsFMenabled');
    }
};

FileManage.removeCallback = function(content, js, html, wObj){
   this.actionsBlock.find('img').removeClass('unvisible');

   content.onEvent('click',function(e){
      var $this = sjs.event.caller(e), i = 2;
      while (!sjs.nodeName($this,'button') && i--) $this = $this.parentNode;
      if(!sjs.nodeName($this,'button')) return false;

      var mn=sjs.globals.fm[this.__file_manager_id],
          wObj = sjs.globals.windows[this.__window_id];

      FileManage.processButtons($this, mn, {
          action: 'remove',
          files: mn.fileStek.concat(mn.dirStek)
      });
      this.onclick = null;
      wObj.close(e,$this);
   });
   content[0].__file_manager_id = this.id;
   content[0].__window_id = wObj.id;
};

FileManage.permsCallback = function(content, js, html, wObj){
    var permsOct = content.onEvent('click', function(e){
        var $this=sjs.event.caller(e),
            mn=sjs.globals.fm[this.__file_manager_id],
            wObj=sjs.globals.windows[this.__window_id];

        if (!sjs.nodeName($this,'input')
            && !sjs.nodeName($this,'button')
            && !(sjs.nodeName($this,'span')
            && sjs.nodeName($this=$this.parentNode,'button'))
        ) return true;

        var permsOct=$this.form['perms[value]'];

        if($this.type=='checkbox'){
            if(isNaN(Number(permsOct.value))) return false;
            if($this.checked){
                permsOct.value=Number(permsOct.value)+Number($this.value);
            }else{
                permsOct.value=Number(permsOct.value)-Number($this.value);
            }
        }else if(sjs.nodeName($this,'button')){
            FileManage.processButtons($this, mn, {
                action: 'perms',
                fileperms: permsOct.value,
                send: permsOct.value != permsOct.title,
                files: mn.fileStek.concat(mn.dirStek)
            });
            this.onclick = null;
            wObj.close(e,$this);
        }
    }).find('input[type=text]').onEvent('keyup',function(){
        if(!isNaN(Number(this.value))){
            var num=null,type=new Array('own','gr','oth'),value=this.value.trim();
            for(var i=0;i<3;i++){
                num=Number(value.charAt(i))||0;
                if(num>=4){
                    this.form['perms['+type[i]+'_read]'].checked=1;
                    num-=4;
                }else{
                    this.form['perms['+type[i]+'_read]'].checked=0;
                }
                if(num>=2){
                    this.form['perms['+type[i]+'_write]'].checked=1;
                    num-=2;
                }else{
                    this.form['perms['+type[i]+'_write]'].checked=0;
                }
                if(num>=1){
                    this.form['perms['+type[i]+'_exec]'].checked=1;
                }else{
                    this.form['perms['+type[i]+'_exec]'].checked=0;
                }
            }
            num=type=value=null;
        }
    });
    content[0].__file_manager_id = this.id;
    content[0].__window_id = wObj.id;

    permsOct.trigger('keyup');
    //permsOct[0].select();
    permsOct[0].title = permsOct[0].value;
};

FileManage.createDirCallback = function(content, js, html, wObj){
    var form = content.onEvent('click', function(e){
        var $this = sjs.event.caller(e), i = 2;
        while (!sjs.nodeName($this,'button') && i--) $this = $this.parentNode;
        if(!sjs.nodeName($this,'button')) return false;

        var mn=sjs.globals.fm[this.__file_manager_id],
            wObj = sjs.globals.windows[this.__window_id],
            dirname=sjs.trim($this.form.filename.value);

        FileManage.processButtons($this, mn, {
            action: 'create_dir',
            dirname: dirname,
            send: !!dirname && !/[\:\/*?'"<>|]/.test(dirname)
        });
        this.onclick = null;
        wObj.close(e,$this);
    }).find('form').onEvent('submit',function(){return false})[0];
    content[0].__file_manager_id = this.id;
    content[0].__window_id = wObj.id;

    sjs(form.filename).onEvent('keyup',function(e){
        var key=sjs.event.key(e), c=key.code,
            invalid=/[\:\/*?'"<>|]/.test(this.value),
            errBlock = sjs(this.form).find('div.error');

        if(invalid){
            errBlock.css('display', 'block');
        } else if(c==13){
            this.form.ok.click();
            return false
        } else if(errBlock[0].style.display) {
            errBlock.css('display', '');
        }
    })[0].focus();
};

FileManage.renameCallback = function(e){
    var mn = sjs.globals.fm[this.__file_manage_id],
        files = mn.dirStek.concat(mn.fileStek);

    this.value = String(this.value).trim();
    if(!this.value || this.value == String(files[0]).trim()){
        var td = this.parentNode.parentNode,
            p = files[0].lastIndexOf('.');
            filename = files[0];

        if (p && p != -1) {
            filename = filename.substr(0, p);
        }

        sjs(td).attr('colSpan', 1).next().css('display', '');
        sjs(this.parentNode).html(filename);
        return false;
    }
    mn.actionsBlock.find('img').removeClass('unvisible');
    sjs.query(mn.actionUrl,{
        files: files,
        fileNames: [this.value],
        action: 'rename',
        path: mn.getCurrentPath()
    }, FileManage.ajaxCallback, true, {
        object_id: mn.id
    });
    sjs.event.unselect(mn.lastClicked.offsetParent.parentNode);
};

FileManage.uploadCallback = function(content, js, html, wObj){
    var btn = content.find('button[name="upload"]').onEvent('click', function(){
        var mn = sjs.globals.fm[this.__file_manager_id];
        mn.uploadObject.startUpload();
    });
    btn[0].__file_manager_id = this.id;
};

FileManage.createWindow = function(cfg, contentType, url, onclose){
   if (contentType) {
      cfg.content = sjs('#sj'+sjs.capitalize(contentType)+'Tmpl')[0].innerHTML
   }

   if (cfg.arguments) {
      cfg.arguments.file_manage_id = cfg.id;
   }

   var w=new sjWindow(url, sjs.extend({
      title:$_LANG.VIEW_PROPERTY,
      tmpl:'#sjWindowTmpl',
      isModal:true,
      action:'001',
      onChangeSize:function(content){
          var size = content.getSize();
          sjs(this.window).css('width', size.width + size.margin[1] + size.margin[3] + 'px')
      }
   }, cfg || {}),function(content,js,html){
      var callback = this.arguments.action + 'Callback';

      if (js && js.response && js.response.status == 'error'){
         content.text(js.response.msg)
      } else if (sjs.isFn(FileManage[callback])) {
         FileManage[callback].call(
            sjs.globals.fm[this.arguments.file_manage_id],
            content,
            js,
            html,
            this
         )
      }
      this.position();
   });

   return w
};

FileManage.processButtons = function(btn, mn, cfg, callback){
    var type = btn.name, apply = true;
    if ('send' in cfg){
        apply = cfg.send;
        delete cfg.send;
    }

    switch (type) {
        case 'ok':
            if(!apply) return false;

            mn.makeStek();
            sjs.query(mn.actionUrl,sjs.extend({
               path: mn.getCurrentPath()
            }, cfg || {}),
            sjs.isFn(callback) && callback || FileManage.ajaxCallback, 1, {
               object_id: mn.id
            });
        break;
        default:
            mn.actionsBlock.find('img').setClass('unvisible');
        break;
    }
};

FileManage.getInstance = function(callback, url, fmCfg, windowCfg) {
    if (callback === null) {
        if (FileManage.instance) {
            FileManage.instance.__destruct();
            FileManage.windowInstance.__destruct();
        }
        FileManage.instanceSettings = [url, fmCfg, windowCfg];
    } else {
        var onInit = function(){
            if (sjs.isFn(callback)) {
                FileManage.instance.setAction('insert', callback);
            } else if (callback === null) {
                FileManage.instance.actionsBlock.find('*[name="insert"]').css('display', 'none');
            }
            FileManage.windowInstance.show().position();
            FileManage.instance.reset();
        };
        if (FileManage.instanceSettings) {
            var url   = FileManage.instanceSettings[0],
                fmCfg =  FileManage.instanceSettings[1],
                windowCfg =  FileManage.instanceSettings[2];
            FileManage.instanceSettings = null;
        }
        if (!FileManage.windowInstance) {
            FileManage.onInit = onInit;
            var w = new sjWindow(url, sjs.extend({
                title: $_LANG.PROJECT_TITLE,
                tmpl: '#sjWindowTmpl',
                isModal: true,
                action: '001',
                arguments: { fmCfg: fmCfg }
            }, windowCfg || {}), function(content, js, html){
                var cfg = this.arguments.fmCfg, events = cfg.events;
                if (events) {
                    delete cfg.events;
                }
                if (!cfg.actionSel) {
                    cfg.actionSel = '#sjFmActions';
                }
                FileManage.instance = new FileManage(sjs(cfg.element || '#sjFilemanager'), cfg, events);
                FileManage.onInit();
                FileManage.onInit = null;
                this.position().toInnerSize();
            });
            sjs(w.window).removeClass('ie6_width_fix')
                .find('.sjs_wcontent')
                .setClass('sjDimensions');
            w.onclose = function(){
                this.hide();
                return false;
            };
            FileManage.windowInstance = w.hide();
        } else {
            onInit();
        }
        return FileManage.windowInstance;
    }
};

FileManage.choiseCallback = function(field, url, type, win){
    FileManage.getInstance(function(){
        this.makeStek();
        if (this.fileStek && this.fileStek.length) {
            var args = FileManage.windowInstance.arguments,
                field = args.field, url = args.url + this.getCurrentPath();

            if (typeof field == 'string') {
                field = sjs(args.win.document.getElementById(field));
            } else if (!field.sjs) {
                field = sjs(field);
            }

            switch (args.type) {
                case 'multiple':
                    field.prop('value', url + '|' + this.fileStek.join(":"));
                break;
                default:
                    field.prop('value', url + this.fileStek[0]);
                break;
            }
            field.trigger('change');
            FileManage.windowInstance.close();
        }
    }).setArguments({
        field: field,
        url: url,
        type: type,
        win: win
    })
};
