<?php $base_url = str_replace($_SERVER['DOCUMENT_ROOT'], '', dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . 'web'; $root_url = '/media/uploads'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>sjFilemanager</title>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/lang/lang_ru.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/sjs/sjs.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/sjs/sjs.request.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/sjs/sjs.animate.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/windows.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/filemaneger.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/swfupload/handlers.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/swfupload/swfupload.js"></script>
    <link href="<?php echo $base_url ?>/css/desktop.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="/tools/tiny_mce/tiny_mce.js"></script>
    <script type="text/javascript">
        sjs.ready(function(){
            var w = FileManage.getInstance(null, "<?php echo $base_url ?>/?tmpl=window&show_actions=1", {
                dirUrl: '<?php echo $base_url ?>/',
                actionUrl: '<?php echo $base_url ?>/',
                actionSel: '#sjFmActions',
                events: {
                    onServerError: function(js, html) {
                        FileManage.createWindow({
                            id: this.id,
                            title: $_LANG.TITLE_WARNING,
                            content: '<p>' + js.response.msg + '</p>'
                        });
                    }
                },
                upload: {
                    object:  SWFUpload,
                    onReadyEventName: 'file_dialog_complete_handler',
                    flash_url : "<?php echo $base_url ?>/js/swfupload/swfupload.swf",
                    file_post_name:'files',
                    custom_settings : {
                        progressTarget : "sjFmUploadProgress"
                    },
                    file_size_limit : "800MB",
                    file_types : "*.*",
                    file_types_description : "All Files",
                    file_upload_limit : 100,
                    file_queue_limit : 0,

                    button_text_left_padding: 5,
                    button_text_top_padding: 1,
                    button_image_url: "<?php echo $base_url ?>/js/swfupload/sbtn.png",
                    button_placeholder_id: "sjFmButtonPlaceHolder",
                    button_text: '<span class="submit">Файлы...</span>',
                    button_width: "65",
                    button_text_style: ".submit { font-size: 11; color:#000000; font-family:Tahoma, Arial, serif; }",
                    button_height: "20",
                    file_queued_handler: fileQueued,
                    file_queue_error_handler: fileQueueError,
                    upload_start_handler: uploadStart,
                    upload_progress_handler: uploadProgress,
                    upload_error_handler: uploadError,
                    upload_success_handler: uploadSuccess
                }
            }).find('.sjs_wcontent').setClass('dimensions');
            
            sjs('#container').onEvent('click', function(e){
                var $this = sjs.event.caller(e);
                if (!sjs.nodeName($this, 'a')) {
                    return true;
                }
                
                $this.parentNode.parentNode.removeChild($this.parentNode);
                return false;
            });
            sjs('#customCallback').onEvent('click', function(e){
                FileManage.getInstance(function(){
                    var data = this.getChecked(), i = data.length,
                        wr = 0, url = "<?php echo $root_url ?>" + this.getCurrentPath(),
                        ins = sjs('#container');
                        
                    if (!i) {
                        return false;
                    }
                    
                    while (i--) {
                        var label = sjs(data[i].cells[1]).first()[0], html = '',
                            file  = url + sjs(data[i]).find('input[type="checkbox"]:checked')[0].value.trim();
                        wr = sjs('<div class="wrapps"></div>')
                        
                        if (/\s+(?:jpe?g|gif|png)\s+/i.test(' '+label.className+' ')) {
                            html = '<img src="' + file + '" alt="'+file+'" style="max-width:100px" />';
                        } else {
                            html = '<span>'+file+'</span>';
                        }
                        html += '<br /><a href="#">delete</a><input type="hidden" name="files[]" value="'+file+'" />';
                        ins.append(wr.html(html));
                    }
                    FileManage.windowInstance.close();
                });
                return false;
            })
        });

        tinyMCE.init({
            // General options
            mode : "textareas",
            theme : "advanced",
            plugins : "media,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras",
            editor_selector : "mceEditor",
            language : "en",
            convert_urls: false, 
            theme : "advanced",
            debug : false,
            paste_auto_cleanup_on_paste : true,
            paste_convert_headers_to_strong : true,		
            // Theme options
            theme_advanced_buttons1 :"undo,redo,|,bold,italic,underline,strikethrough,forecolor,backcolor,|,sub,sup,charmap,|,hr,removeformat",
            theme_advanced_buttons2 : "pastetext,pasteword,|,search,|,bullist,numlist,|,outdent,indent,|,link,unlink,image,media,cleanup,code,fullscreen",
            theme_advanced_buttons3 : "tablecontrols",
            //theme_advanced_buttons4 : "styleselect,formatselect,fontselect,fontsizeselect",
            theme_advanced_toolbar_location : "top",
            theme_advanced_toolbar_align : "left",
            theme_advanced_statusbar_location : false,
            file_browser_callback: function(field, url, type, win){
                FileManage.choiseCallback(field, "<?php echo $root_url?>", type, win);
            }
        });
    </script>
</head>

<body>
    <div style="float:left;margin-right: 100px">
        <h2>Use in TinyMCE</h2>
        <textarea cols="60" rows="20" class="mceEditor"></textarea>
    </div>
    <div style="float:left">
        <h2>Insert all files in one input</h2>
        <input type="text" name="test_field" /><a href="#" onclick="FileManage.choiseCallback(this.previousSibling,'<?php echo $root_url?>', 'multiple', window); return false">open manager</a><br/>
        <span style="font-size:10px">format: %path_to_dir%|file1:file2:...filen</span>
        
        <h2>Use with custom callback</h2>
        <input type="hidden" name="test_field2" />
        <a href="#" id="customCallback">open manager</a>
        <div id="container"></div>
    </div>
    <div style="clear:both;font-size:1px;height:1px"></div>
    
<!-- Window tmemplate -->
    <div id="sjWindowTmpl" class="hide ie6_width_fix">
        <div class="sjs_wtop">
            <div class="sjs_wltitle"></div>
            <div class="sjs_wrtitle"></div>
            <div class="sjs_wtitle">Window title</div>
            <img src="<?php echo $base_url ?>img/load.gif" alt="" class="upload_img" />
            <div class="sjs_waction">
                <a href="#" class="minimize" onclick="return false;" tabindex="0"></a
                ><a href="#" class="maximize" onclick="return false;" tabindex="0"></a
                ><a href="#" class="close" onclick="return false;" tabindex="0"></a>
            </div>
        </div>
        <div class="window_main">
            <div class="bbottom"></div>
            <div class="bleft"></div>
            <div class="bright"></div>
            <div class="sjs_wcontent"></div>
        </div>
        <div class="sjs_resize">
            <span class="sjs_window_resize n" id="n-resize"></span>
            <span class="sjs_window_resize s" id="s-resize"></span>
            <span class="sjs_window_resize e" id="e-resize"></span>
            <span class="sjs_window_resize w" id="w-resize"></span>
            <span class="sjs_window_resize ne" id="ne-resize"></span>
            <span class="sjs_window_resize nw" id="nw-resize"></span>
            <span class="sjs_window_resize se" id="se-resize"></span>
            <span class="sjs_window_resize sw" id="sw-resize"></span>
        </div>
    </div>
<!-- Window tmemplate -->

</body>
</html>
