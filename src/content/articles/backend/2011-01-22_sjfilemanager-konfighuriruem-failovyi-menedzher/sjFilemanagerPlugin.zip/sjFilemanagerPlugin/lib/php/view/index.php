<?php
/*
 * This file is part of the iFilemanager package.
 * (c) 2010-2011 Stotskiy Sergiy <serjo@freaksidea.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title><?php echo $lang['PROJECT_TITLE'] ?></title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <script type="text/javascript" src="<?php echo dirname(dirname($base_url)) ?>/tiny_mce_popup.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/lang/lang_ru.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/sjs/sjs.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/sjs/sjs.request.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/sjs/sjs.animate.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/windows.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/filemaneger.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/swfupload/handlers.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>/js/swfupload/swfupload.js"></script>
    <link href="<?php echo $base_url ?>/css/desktop.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript"><!--
        sjs.ready(function(){
        <?php require dirname(__FILE__) . '/../js.init.php' ?>
        })
    --></script>
</head>

<body><?php require 'window.php' ?>
<div id="sjWindowTmpl" class="hide">
    <div class="sjs_wtop">
    	<div class="sjs_wltitle"></div>
    	<div class="sjs_wrtitle"></div>
        <div class="sjs_wtitle">Window title</div>
    	<img src="<?php echo $base_url ?>img/load.gif" alt="" class="upload_img" />
        <div class="sjs_waction">
            <a href="#" class="minimize" onclick="return false;" tabindex="0"></a
            ><a href="#" class="maximize" onclick="return false;" tabindex="0"></a
            ><a href="#" class="close" onclick="return false;" tabindex="0"></a>
        </div>
    </div>
	<div class="window_main">
        <div class="bbottom"></div>
        <div class="bleft"></div>
        <div class="bright"></div>
        <div class="sjs_wcontent"></div>
    </div>
    <div class="sjs_resize">
        <span class="sjs_window_resize n" id="n-resize"></span>
        <span class="sjs_window_resize s" id="s-resize"></span>
        <span class="sjs_window_resize e" id="e-resize"></span>
        <span class="sjs_window_resize w" id="w-resize"></span>
        <span class="sjs_window_resize ne" id="ne-resize"></span>
        <span class="sjs_window_resize nw" id="nw-resize"></span>
        <span class="sjs_window_resize se" id="se-resize"></span>
        <span class="sjs_window_resize sw" id="sw-resize"></span>
    </div>
</div>
</body>
</html>
