<?php
/*
 * This file is part of the iFilemanager package.
 * (c) 2010-2011 Stotskiy Sergiy <serjo@freaksidea.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
if (!defined('SJ_IS_ADMIN')) {
    header('Location: http://www.google.com');
    exit;
}

// %Begin Validate $dirpath
$dirpath  = isset($_REQUEST['dirpath']) ? str_replace('\\', DIRECTORY_SEPARATOR, $_REQUEST['dirpath']) : '';
$realpath = realpath($sjConfig['root'] . DIRECTORY_SEPARATOR . $dirpath);

$realLength = strlen($realpath);
$rootLength = strlen($sjConfig['root']);

$cur_dir = substr($realpath, $rootLength);

if(!$realpath || $realLength < $rootLength){ // hack attemt
	$realpath = $sjConfig['root'];
	$cur_dir  =  '';
}
// %End validate $dirpath

$fs = new iFilesystem();
$result = $fs->readDir($realpath, '!r', array( // not recursive
    'sort' => true
));

$data = array();
foreach ($result as &$file) {
    $info = $fs->getPathInfo($file);
    $is_dir = is_dir($file);
    if ($info['basename'][0] == '.') {
        $filename  = $info['basename'];
        $extension = '';
    } else {
        $filename  = $info['filename'];
        $extension = isset($info['extension']) ? $info['extension'] : '';
    }
    $data[] = array(
        'basename' => $info['basename'],
        'name'  => $filename,
        'path'  => $file,
        'size'  => $is_dir ? '' : $fs->formatSize($file) . 'bytes',
        'modify'=> $fs->formatDate(filemtime($file)),
        'type'	=> $extension,
        'is_dir'=> $is_dir
    );
}

$show_actions = isset($_REQUEST['show_actions']) && $_REQUEST['show_actions'];
if (!$_SYSTEM['is_ajax'] || $show_actions) {
    $file_actions = array(
        array('refresh',  '',                         $lang['REFRESH']),
        array('cut',     'onlyFile sjsFMdinamic',     $lang['CUT']),
        array('copy',    'onlyFile sjsFMdinamic',     $lang['COPY']),
        array('remove',  'sjsFMdinamic',              $lang['REMOVE']),
        array('paste',   'sjsFMdisabled sjsFMdinamic',$lang['PASTE']),
        array('rename',  'sjsFMdinamic',              $lang['RENAME']),
        array('perms',   'sjsFMdinamic',              $lang['PERMS']),
        array('createDir', '',                        $lang['CREATE_DIR']),
        array('upload',    '',                        $lang['UPLOAD']),
        array('download',  'sjsFMdisable',            $lang['DOWNLOAD']),
        array('dirInfo',   '',                        $lang['DIR_INFO']),
        array('transform', 'active',                  $lang['TRANSFORM'])
    );
    ksort($file_actions);
    if (isset($sjConfig['allowed_actions'])) {
        foreach ($file_actions as $k => &$action) {
            if (!in_array($action[0], $sjConfig['allowed_actions'])) {
                unset($file_actions[$k]);
            }
        }
    }
} else {
    $file_actions = null;
}

$tmpl = isset($_SYSTEM['template']) && $_SYSTEM['template'] ? $_SYSTEM['template'] : '';
if (!$tmpl) {
    $tmpl = $_SYSTEM['is_ajax'] ? 'dir' : 'index';
}

$view = new iView($tmpl);

$view->render(array(
    'file_actions' => $file_actions,
    'cur_dir'      => $cur_dir,
    'source'       => $data,
    'lang'         => $lang,
    'base_url'     => $sjConfig['base_url'],
    'base_host'    => 'http://' . $_SERVER['HTTP_HOST'],
    'root_url'     => $sjConfig['root_url']
));
?>
