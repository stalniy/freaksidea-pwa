<?php
/*
 * This file is part of the iFilemanager package.
 * (c) 2010-2011 Stotskiy Sergiy <serjo@freaksidea.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
 
/**
 * JavaScript init template
 */
?>
var mn = new FileManage($('#sjFilemanager'), {
    dirUrl: '<?php echo $base_url ?>/',
    actionUrl: '<?php echo $base_url ?>/',
    actionSel: '#sjFmActions',
    upload: {
        object:  SWFUpload,
        flash_url : "<?php echo $base_url ?>/js/swfupload/swfupload.swf",
        file_post_name:'files',
        custom_settings : {
            progressTarget : "fsUploadProgress",
            cancelButtonId : "btnCancel"
        },
        file_size_limit : "800MB",
        file_types : "*.*",
        file_types_description : "All Files",
        file_upload_limit : 100,
        file_queue_limit : 0,

        button_text_left_padding: 5,
        button_text_top_padding: 1,
        button_image_url: "<?php echo $base_url ?>/js/swfupload/sbtn.png",
        button_placeholder_id: "spanButtonPlaceHolder",
        button_text: '<span class="submit"><?php echo $lang['BROWSE'] ?>...</span>',
        button_width: "65",
        button_text_style: ".submit { font-size: 11; color:#000000; font-family:Tahoma, Arial, serif; }",
        button_height: "20",
        file_queued_handler: fileQueued,
        file_queue_error_handler: fileQueueError,
        upload_start_handler: uploadStart,
        upload_progress_handler: uploadProgress,
        upload_error_handler: uploadError,
        upload_success_handler: uploadSuccess
    }
}, {
    onServerError: function(js, html) {
        FileManage.createWindow({
            id: this.id,
            title: $_LANG.TITLE_WARNING,
            content: '<p>' + js.response.msg + '</p>'
        });
    }
});

window.FMDialog = {
    root_url: "<?php echo $root_url ?>",
    init: function(ed) {
        tinyMCEPopup.resizeToInnerSize();
    },
    insert: function(e) {
        $.event.stopPropagation(e);
        var ed = tinyMCEPopup.editor, dom = ed.dom,
            mn = $.globals.fm[this.__file_manager_id], i = 0,
            text = [], data = [], 
            url = window.FMDialog.root_url + mn.getCurrentPath();

        mn.makeStek();
        if (mn.emptyStek()) {
            return false;
        }
        data = mn.fileStek;
        i = data.length;
        if (!i) {
            return false;
        }
        while (i--) {
            text[i] = window.FMDialog.getHtml(data[i], url);
        }
        tinyMCEPopup.execCommand('mceInsertContent', false, text.join(' '));
        tinyMCEPopup.close();
    },
    getHtml: function(filename, url){
        var pos = filename.lastIndexOf('.'),
            ext = '', text = '';
        url += filename;
        
        if (pos && pos != -1) {
            ext = filename.substr(pos + 1);
        }

        if(ext == 'jpeg' || ext == 'jpg' || ext == 'gif' || ext == 'png') {
            text = '<img src="'+url+'" alt="'+filename+'" />';
        } else if(ext == 'swf' || ext == 'flv'){
            text = '<object align="middle" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" >';
            text += '    <param value="opaque" name="wmode"/>';
            text += '    <param value="'+url+'" name="movie"/>';
            text += '    <param value="always" name="AllowScriptAccess"/>';
            text += '    <param value="high" name="quality"/>';
            text += '    <embed align="middle" ';
            text += '    pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" allowscriptaccess="always"   wmode="opaque" quality="high" src="'+url+'"/>';
            text += '</object>';
        } else {
            text = '<a href="'+url+'" title="'+filename+'" >'+ filename + '</a>';
        }
        
        return text;
    }
};
//window.FMDialog.init();
//$('#insert_files').onEvent('click', window.FMDialog.insert)[0].__file_manager_id = mn.id;
return mn
