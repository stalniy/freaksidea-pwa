<?php
/*
 * This file is part of the iFilemanager package.
 * (c) 2010-2011 Stotskiy Sergiy <serjo@freaksidea.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
?>
<button class="btn-submit no_bg no_border <?php echo $btn_class ?>" type="<?php echo $type ?>" name="<?php echo $btn_name ?>" value="<?php echo $btn_value ?>"><span class="leftImg">&nbsp;</span><span class="submit"><?php echo $label ?></span><span class="rightImg">&nbsp;</span></button>
