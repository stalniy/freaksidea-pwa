<?php
$base_url = url_for('@sjFilemanager');
$web_root = '/sjFilemanagerPlugin';
use_stylesheet($web_root . '/css/desktop.css');
use_javascript($web_root . '/js/lang/lang_ru.js');
use_javascript($web_root . '/js/pack/sjs.js');
use_javascript($web_root . '/js/pack/swfupload.js');
use_javascript($web_root . '/js/pack/sjFilemanager.js');
?>
<script type="text/javascript">
sjs.ready(function(){
    FileManage.getInstance(null, "<?php echo $base_url ?>?tmpl=window&show_actions=1", {
        dirUrl: '<?php echo $base_url ?>',
        actionUrl: '<?php echo $base_url ?>',
        actionSel: '#sjFmActions',
        events: {
            onServerError: function(js, html) {
                FileManage.createWindow({
                    id: this.id,
                    title: $_LANG.TITLE_WARNING,
                    content: '<p>' + js.response.msg + '</p>'
                });
            }
        },
        upload: {
            object:  SWFUpload,
            flash_url : "<?php echo $web_root ?>/js/swfupload/swfupload.swf",
            file_post_name:'files',
            custom_settings : {
                progressTarget : "sjFmUploadProgress"
            },
            file_size_limit : "10MB",
            file_types : "*.*",
            file_types_description : "All Files",
            file_upload_limit : 100,
            file_queue_limit : 0,

            button_text_left_padding: 5,
            button_text_top_padding: 1,
            button_image_url: "/<?php echo $web_root ?>/js/swfupload/sbtn.png",
            button_placeholder_id: "sjFmButtonPlaceHolder",
            button_text: '<span class="submit">' + $_LANG.UPLOAD_BTN_TEXT + '</span>',
            button_width: "65",
            button_text_style: ".submit { font-size: 11; color:#000000; font-family:Tahoma, Arial, serif; }",
            button_height: "20",
            file_queued_handler: fileQueued,
            file_queue_error_handler: fileQueueError,
            upload_start_handler: uploadStart,
            upload_progress_handler: uploadProgress,
            upload_error_handler: uploadError,
            upload_success_handler: uploadSuccess
        }
    }).find('.sjs_wcontent').setClass('dimensions');
});
</script>
<div id="sjWindowTmpl" style="display:none">
    <div class="sjs_wtop">
    	<div class="sjs_wltitle"></div>
    	<div class="sjs_wrtitle"></div>
        <div class="sjs_wtitle">Window title</div>
    	<img src="<?php echo $base_url ?>img/load.gif" alt="" class="upload_img" />
        <div class="sjs_waction">
            <a href="#" class="minimize" onclick="return false;" tabindex="0"></a
            ><a href="#" class="maximize" onclick="return false;" tabindex="0"></a
            ><a href="#" class="close" onclick="return false;" tabindex="0"></a>
        </div>
    </div>
	<div class="window_main">
        <div class="bbottom"></div>
        <div class="bleft"></div>
        <div class="bright"></div>
        <div class="sjs_wcontent"></div>
    </div>
</div>
