<?php
class sjFilemanagerActions extends sfActions {
    public function executeIndex(sfWebRequest $request) {
        $webDir = dirname(dirname(dirname(dirname(__FILE__))));
        require $webDir . DIRECTORY_SEPARATOR . 'index.php';

        $this->setLayout(false);
        return sfView::NONE;
    }
}
