<?php
require_once 'app/code/core/Mage/Catalog/controllers/CategoryController.php';
class Freaks_Products_IndexController extends Mage_Catalog_CategoryController
{
    /**
     * Initialize requested category object
     *
     * @return Freaks_Products_IndexController
     */
    protected function _initCatagory()
    {
        Mage::dispatchEvent('catalog_controller_category_init_before', array('controller_action' => $this));
        $categoryId = (int) $this->getRequest()->getParam('id', false);
        if (!$categoryId) {
            return false;
        }

        $category = Mage::getModel('catalog/category')
            ->setStoreId(Mage::app()->getStore()->getId())
            ->load($categoryId);

        $isRootCategory = !$category->isInRootCategoryList();
        if (!$isRootCategory && !Mage::helper('catalog/category')->canShow($category)) {
            return false;
        }

        if (!$isRootCategory) {
            Mage::getSingleton('catalog/session')->setLastVisitedCategoryId($category->getId());
        }
        Mage::register('current_category', $category);
        try {
            Mage::dispatchEvent(
                'catalog_controller_category_init_after',
                array(
                    'category' => $category,
                    'controller_action' => $this
                )
            );
        } catch (Mage_Core_Exception $e) {
            Mage::logException($e);
            return false;
        }

        return $category;
    }

    protected function _emulateCategory($categoryId, $categoryTitle)
    {
        $this->getRequest()->setParam('id', $categoryId);

        $category = $this->_prepareView();
        $category->setName($categoryTitle)
            ->setIsEmulated(true);

        // reset layout rendering
        if ($head = $this->getLayout()->getBlock('head')) {
            $head->setTitle($categoryTitle);
        }

        if ($breadcrumb = $this->getLayout()->getBlock('breadcrumbs')) {
            $breadcrumb->addCrumb('specials', array(
                'readonly' => true,
                'title'    => $categoryTitle,
                'label'    => $categoryTitle
            ));
        }

        if ($list = $this->getLayout()->getBlock('product_list')) {
            return $list->getLoadedProductCollection();
        }
        Mage::throwException($this->__('Unable to find products collection'));
    }

    protected function _prepareView()
    {
        if ($category = $this->_initCatagory()) {
            $design = Mage::getSingleton('catalog/design');
            $settings = $design->getDesignSettings($category);

            // apply custom design
            if ($settings->getCustomDesign()) {
                $design->applyCustomDesign($settings->getCustomDesign());
            }

            Mage::getSingleton('catalog/session')->setLastViewedCategoryId($category->getId());

            $update = $this->getLayout()->getUpdate();
            $update->addHandle('default');

            if (!$category->hasChildren()) {
                $update->addHandle('catalog_category_layered_nochildren');
            }

            $this->addActionLayoutHandles();
            $update->addHandle($category->getLayoutUpdateHandle());
            $update->addHandle('CATEGORY_' . $category->getId());
            $this->loadLayoutUpdates();

            // apply custom layout update once layout is loaded
            if ($layoutUpdates = $settings->getLayoutUpdates()) {
                if (is_array($layoutUpdates)) {
                    foreach($layoutUpdates as $layoutUpdate) {
                        $update->addUpdate($layoutUpdate);
                    }
                }
            }

            $this->generateLayoutXml()->generateLayoutBlocks();
            // apply custom layout (page) template once the blocks are generated
            if ($settings->getPageLayout()) {
                $this->getLayout()->helper('page/layout')->applyTemplate($settings->getPageLayout());
            }

            if ($root = $this->getLayout()->getBlock('root')) {
                $root->addBodyClass('categorypath-' . $category->getUrlPath())
                    ->addBodyClass('category-' . $category->getUrlKey());
            }

            $this->_initLayoutMessages('catalog/session');
            $this->_initLayoutMessages('checkout/session');
            return $category;
        } elseif (!$this->getResponse()->isRedirect()) {
            $this->_forward('noRoute');
        }
    }

    public function lastAction()
    {
        $id   = Mage::app()->getStore()->getRootCategoryId();
        $name = Mage::helper('catalog')->__('Last Products');

        try {
            $productCollection = $this->_emulateCategory($id, $name);
            // filter products in some way
            $productCollection->setOrder('entity_id', 'desc');

            if ($layer = $this->getLayout()->getBlock('catalog.leftnav')) {
                // set visible filters
                #$layer->setVisibleFilters(array('price', 'manufacturer'));
            }
        } catch (Exception $e) {
            return $this->_redirect('');
        }

        $this->renderLayout();
    }

    public function specialsAction()
    {
        $id   = Mage::app()->getStore()->getRootCategoryId();
        $name = Mage::helper('catalog')->__('Special Products');

        try {
            $productCollection = $this->_emulateCategory($id, $name);

            $date = Mage::getModel('core/date');
            $productCollection->addCategoryIds()
                ->addAttributeToSort('special_from_date','desc')
                ->addAttributeToFilter('special_from_date', array(
                    'date' => true, 'to' => $date->date()
                ))
                ->addAttributeToFilter('special_to_date', array( 'or' => array(
                    0 => array('date' => true, 'from' => $date->timestamp() + 86400), // tomorrow date
                    1 => array('is'   => new Zend_Db_Expr('null')))
                ), 'left');


            if ($layer = $this->getLayout()->getBlock('catalog.leftnav')) {
                // set visible filters
                #$layer->setVisibleFilters(array('price', 'manufacturer'));
            }
        } catch (Exception $e) {
            return $this->_redirect('');
        }

        $this->renderLayout();
    }
}
