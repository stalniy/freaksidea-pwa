<?php
$str = '{
    "lang": "ru",
    "charset": "utf-8",
    "lib_dir": "/home/pub/www/sjfm/sj_filemanager/lib/php",
    "root":  "/home/pub/www/sjfm/uploads",
    //"allowed_actions": [],
    "uploader": {
        "max_size": "104857600",
        "allowed_types": ["jpeg","jpg","rar","png","doc","docx","ppt","pptx","xls","xlsx","mdb","accdb", "swf", "zip", "rtf", "pdf", "psd", "mp3", "wma", "flv", "mp4"],
        "dynamic_name": true,
        "override": false,
        "images": {
            "width": 500,
            "height": 500,
            // width, height, auto, percentage
            "type": "width",
            // left-top, left-bottom, center, right-top, right-bottom, custom {"x": 100, "y": 200}
            "crop": "left-top"
        },
        "thumbs": {
            //"tmb_": {
            //  "width": 125,
            //  "height": 70,
            //  "type": "width",
            //  "crop": "left-top"
            //},
            //"mcr_": {
            //    "width": 50,
            //    "height": 50,
            //    "type": "width",
            //    "crop": "left-top"
            //}
        }
    }
}';

function prepareConfig($config) {
    $max_size = ini_get('post_max_size');
    $unit = strtoupper(substr($max_size, -1));
    $multiplier = ($unit == 'M' ? 1048576 : ($unit == 'K' ? 1024 : ($unit == 'G' ? 1073741824 : 1)));

    $constants = array(
        '%BASE_DIR%'      => dirname(dirname(dirname(__FILE__))),
        '%DOCUMENT_ROOT%' => rtrim($_SERVER['DOCUMENT_ROOT'], '/'),
        '%POST_MAX_SIZE%' => $multiplier * (float)$max_size
    );

    $config = preg_replace('!^\s*(?://|#).++\s!m', '', $config);
    $config = strtr($config, $constants);
    return $config;
}

$config = prepareConfig($str);
echo $config, "\n";
print_r(json_decode($config, true));
echo "\n";
