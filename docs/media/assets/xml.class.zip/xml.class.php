<?php
/**
 * Xml parser
 *
 * @category    Parser
 * @package     Xml
 * @author      Sergiy Stotskiy <sergiy.stotskiy@gmail.com>
 */
class sjXmlParser implements SeekableIterator
{
    protected
        /**
         * Source file path.
         *
         * @var string
         */
        $_source,

        /**
         * Source file handler.
         *
         * @var resource
         */
        $_fileHandler,

        /**
         * Current row number.
         *
         * @var int
         */
        $_currentKey   = 0,

        /**
         * Current row.
         *
         * @var array
         */
         $_currentRow,

        /**
         * Xml charset
         * @var string
         */
        $_charset,

        /**
         * Xml row tag mapping
         * @var array
         */
        $_tagMap       = array(),

        /**
         * Xml row default values
         * @var array
         */
        $_defaultValues = array(),

        /**
         * Ignore all tags that is not specified in $_tagMap
         * @var bool
         */
        $_ignoreNotMappingTags = false,

        /**
         * Reading tags stack
         * @var array
         */
        $_stack = array(),

        /**
         * Xml parser source
         * @var resource
         */
        $_parser,

        /**
         * Current parsing tag name
         * @var string
         */
        $_current    = '',

        /**
         * Reading buffer size (in bytes)
         * @var integer
         */
        $_bufferSize = 4096,

        /**
         * Xml row tag name
         * @var string
         */
        $_rowTagName,

        /**
         * Is parsing stopped in xml row
         * @var bool
         */
        $_isInRow    = false,

        /**
         * Is parsing stopped in row data
         * @var bool
         */
        $_isInData   = false,

        /**
         * Parsed rows
         * @var integer
         */
        $_rowIndex   = -1,

        /**
         * Temporary array to avoid data losing
         * @var string
         */
        $_data        = array();

    public function __construct($source, $charset = 'UTF-8')
    {
        if (!is_string($source)) {
            throw new Exception('Source file path must be a string');
        }
        if (!is_readable($source)) {
            throw new Exception(sprintf("%s file does not exists or is not readable", $source));
        }
        $this->_source  = $source;
        $this->_charset = $charset;
        $this->_initialize();
    }

    /**
     * Initialize parser
     *
     * @return sjXmlParser
     */
    protected function _initialize()
    {
        $this->_parser = xml_parser_create($this->_charset);
        xml_set_object($this->_parser, $this);
        xml_set_element_handler($this->_parser, '_parseOpenTag', '_parseCloseTag');
        xml_set_character_data_handler($this->_parser, '_parseContent');

        $this->setOption(XML_OPTION_CASE_FOLDING, false);

        $this->_fileHandler = fopen($this->_source, 'r');
        if (!$this->_fileHandler) {
            throw new Exception("Unable to read xml file");
        }

        return $this;
    }

    /**
     * Set xml row tag name
     *
     * @param string $tag
     * @return sjXmlParser
     */
    public function setRowTagName($tag)
    {
        $this->_rowTagName = $tag;
        return $this;
    }

    /**
     * Set read buffer size
     *
     * @param int $size
     * @return sjXmlParser
     */
    public function setBufferSize($size)
    {
        if (is_numeric($size)) {
            $this->_bufferSize = (int)$size;
        }

        return $this;
    }

    /**
     * Set ignore not mapping tags flag
     *
     * @param bool $flag
     * @return sjXmlParser
     */
    public function setIgnoreNotMappingTags($bool)
    {
        $this->_ignoreNotMappingTags = (bool)$bool;
        return $this;
    }

    /**
     * Set option for xml parser
     *
     * @param int $name
     * @param mixed $value
     * @return sjXmlParser
     */
    public function setOption($name, $value)
    {
        xml_parser_set_option($this->_parser, $name, $value);
        return $this;
    }

    /**
     * Get option
     *
     * @param int $name
     * @return mixed
     */
    public function getOption($name)
    {
        return xml_parser_get_option($this->_parser, $name);
    }

    /**
     * Parse open xml tag
     *
     * @param resource $parser
     * @param string $name
     * @param array $attrs
     * @return void
     */
    protected function _parseOpenTag($parser, $name, $attrs)
    {
        array_push($this->_stack, $this->_current);
        if (!isset($this->_stack[2]) && $name == $this->_rowTagName) {
            $this->_isInRow = true;
            $this->_rowIndex++;
        }
        $this->_current  = $name;
        $this->_isInData = false;
    }

    /**
     * Parse close xml tag
     *
     * @param resource $parser
     * @param string $name
     * @return void
     */
    protected function _parseCloseTag($parser, $name)
    {
        $this->_current  = array_pop($this->_stack);
        $this->_isInData = false;

        if (!isset($this->_stack[2]) && $name == $this->_rowTagName) {
            $this->_isInRow = false;
        }
    }

    /**
     * Parse xml tag content
     *
     * @param resource $parser
     * @param string $data
     * @return bool
     */
    protected function _parseContent($parser, $data)
    {
        if (isset($this->_stack[2])
            && $this->_stack[2] == $this->_rowTagName // in row
            && $data[0] != "\n" // tag tree
        ) {
            $xpath   = array_slice($this->_stack, array_search($this->_rowTagName, $this->_stack) + 1);
            $xpath[] = $this->_current;

            $row = &$this->_data[$this->_rowIndex];
            if (isset($xpath[1])) {
                $this->_buildStructure($row, $xpath, $data);
            } elseif ($tagName = $this->_mapTag($this->_current)) {
                if (!is_array($tagName)) {
                    $tagName = array($tagName);
                }
                if ($this->_isInData) {
                    foreach ($tagName as $name) {
                        $row[$name] .= $data;
                    }
                } else {
                    foreach ($tagName as $name) {
                        $row[$name] = $data;
                    }
                }

            }
            $this->_isInData = true;
        }
        return true;
    }

    /**
     * Build array structure by xpath
     *
     * @param array $row
     * @param array $xpath
     * @param string $value
     * @return bool
     */
    protected function _buildStructure(&$row, $xpath, $value = '')
    {
        $tmpXpath = array();
        foreach ($xpath as $i => $name) {
            $realName = $name;
            $name     = $this->_mapTag($name, $tmpXpath);
            if (!$name) {
                return false;
            }

            $tmpXpath[] = $realName;
            if (!is_array($name)) {
                $name = array($name);
            }
            foreach ($name as $part) {
                if (!is_array($row[$part])) {
                    $content = $row[$part];
                    $row[$part] = array();
                    if ($content) {
                        $row[$part][] = $content;
                    }
                }
                $row = &$row[$part];
            }
        }

        if ($this->_isInData) {
            if (is_array($row)) {
                $row[count($row) - 1] .= $value;
            } else {
                $row .= $value;
            }
        } else {
            if (!empty($row)) {
                if (!is_array($row)) {
                    $row = array($row);
                }
                $row[] = $value;
            } else {
                $row = $value;
            }
        }
        return true;
    }

    /**
     * Map tag according to self::$_tagMap
     *
     * @param string $tagName
     * @param array  $xpath
     * @return bool|string
     */
    protected function _mapTag($tagName, $xpath = array())
    {
        $xpath[] = $tagName;
        $xpath = join('/', $xpath);
        if (isset($this->_tagMap[$xpath])) {
            return $this->_tagMap[$xpath];
        } elseif ($this->_ignoreNotMappingTags) {
            return false;
        }
        return $tagName;
    }

    /**
     * Add tag mapping
     *
     * @param string|array $map
     * @param $attribute
     * @return sjXmlParser
     */
    public function addTagMap($map, $attribute = null)
    {
        if (is_array($map)) {
            $this->_tagMap = $map + $this->_tagMap;
        } else {
            $this->_tagMap[$map] = $attribute;
        }
        return $this;
    }

    /**
     * Add default values
     *
     * @param array $defaults
     * @return sjXmlParser
     */
    public function addDefaults(array $defaults)
    {
        $this->_defaultValues = $defaults + $this->_defaultValues;
        return $this;
    }

    /**
     * Object destructor. Close file and free xml parser
     *
     * @return void
     */
    public function __destruct()
    {
        if (is_resource($this->_fileHandler)) {
            fclose($this->_fileHandler);
        }
        xml_parser_free($this->_parser);
    }

    /**
     * Read row from xml file
     *
     * @return array current row
     */
    protected function _readRow()
    {
        if (!isset($this->_data[$this->_currentKey]) || $this->_isInRow && $this->_currentKey == $this->_rowIndex) {
            if (empty($this->_data[$this->_currentKey])) {
                $this->_data = array();
            } else {
                $this->_data = array(
                    $this->_currentKey => $this->_data[$this->_currentKey]
                );
            }
            do {
                $isFinal= feof($this->_fileHandler);
                $data   = fread($this->_fileHandler, $this->_bufferSize);
                $result = xml_parse($this->_parser, $data, $isFinal);
                if (!$result) {
                    throw new Exception(sprintf('XML error at line %d column %d',
                        xml_get_current_line_number($this->_parser),
                        xml_get_current_column_number($this->_parser)
                    ));
                }
            } while ((empty($this->_data) || $this->_isInRow && count($this->_data) == 1) && !$isFinal);
        }

        if (!empty($this->_data[$this->_currentKey])) {
            $this->_currentRow = $this->_data[$this->_currentKey] + $this->_defaultValues;
        } else {
            $this->_currentRow = array();
            $this->_currentKey = null;
        }

        return $this->_currentRow;
    }

    /**
     * Move forward to next element
     *
     * @return sjXmlParser
     */
    public function next()
    {
        $this->_currentKey++;
        $this->_readRow();
        return $this;
    }

    /**
     * Return the current row
     *
     * @return array
     */
    public function current()
    {
        return $this->_currentRow;
    }

    /**
     * Return the key of the current element.
     *
     * @return int More than 0 integer on success, integer 0 on failure.
     */
    public function key()
    {
        return $this->_currentKey;
    }

    /**
     * Checks if current position is valid.
     *
     * @return boolean Returns true on success or false on failure.
     */
    public function valid()
    {
        return !empty($this->_currentRow);
    }

    /**
     * Rewind the Iterator to the first element.
     *
     * @return sjXmlParser
     */
    public function rewind()
    {
        // rewind resource, read first row as current
        rewind($this->_fileHandler);
        $this->_currentKey = 0;
        $this->_readRow();
        return $this;
    }

    /**
     * Seeks to a position
     *
     * @throws OutOfBoundsException
     * @param int $position The position to seek to.
     * @return sjXmlParser
     */
    public function seek($position)
    {
        if ($position != $this->_currentKey || empty($this->_currentRow)) {
            if (0 == $position) {
                return $this->rewind();
            } elseif ($position > 0) {
                if ($position < $this->_currentKey) {
                    $this->rewind();
                }
                do {
                    $this->next();
                    if ($this->_currentKey == $position) {
                        return $this;
                    }
                } while ($this->valid());
            }
            throw new OutOfBoundsException('Invalid seek position');
        }
        return $this;
    }
}
